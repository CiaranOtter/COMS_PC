make clean all
mpiexec -n 8 ./main